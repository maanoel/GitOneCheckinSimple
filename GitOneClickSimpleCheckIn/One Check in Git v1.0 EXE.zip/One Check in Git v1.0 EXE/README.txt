#########################MANOLOS###########################

Extraia o contéudo do arquivo inteiro na mesma pasta.

Em seguida execute o GitOneClickSimpleCheckIn.exe
